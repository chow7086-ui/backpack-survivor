# res://Script/player.gd
extends CharacterBody2D

@export var bullet_scene: PackedScene = preload("res://Scene/bullet.tscn")

const BASE_MAX_HP: int = 15
const BASE_MAX_SPEED: float = 300.0
const BASE_BUDGET_RECOVERY_RATE: float = 15.0

# 📊 屬性與資源
var max_hp: int = BASE_MAX_HP
var current_hp: int = max_hp
var max_budget: float = 100.0
var current_budget: float = max_budget
var budget_recovery_rate: float = BASE_BUDGET_RECOVERY_RATE

# --- MOVEMENT PHYSICS ---
@export var max_speed: float = 300.0
@export var acceleration: float = 1500.0  
@export var friction: float = 1500.0      

# --- PROGRESSION SYSTEM ---
var current_exp: int = 0
var max_exp: int = 3
var player_level: int = 1

# --- BACKEND INVENTORY SYSTEM ---
var inventory_items: Array[ItemData] = []

# --- WEAPON LEVEL DATABASE ---
var weapon_level: int = 1 
var discount_sword_level: int = 0
var greatsword_level: int = 0
var rumor_wand_level: int = 0 

# ⏱️ 獨立武器冷卻追蹤器
var cooldowns: Dictionary = {
	"sword": 0.0,
	"greatsword": 0.0,
	"wand": 0.0
}

# --- JUICE & EFFECTS VARIANCE ---
var gem_timestamps: Array = []       
var dialogue_cooldown: float = 0.0   
var showing_level_up: bool = false
var is_slacking: bool = false 
var glow_tween: Tween = null
var touch_damage_cooldown: float = 0.0

@onready var player_sprite = $Sprite2D 
@onready var level_up_label: Label = get_node_or_null("LevelUpLabel") 

func _ready() -> void:
	add_to_group("player") 
	if has_node("HurtBox"):
		$HurtBox.body_entered.connect(_on_hurt_box_body_entered)
	
	if has_node("AutoShootTimer"):
		$AutoShootTimer.queue_free() 
		
	recalculate_stats()
	current_hp = max_hp

# 🎯 --- 核心主迴圈 ---
func _process(delta: float) -> void:
	# 🎯【殭屍防禦哨 1】：如果血量已經小於等於 0，徹底躺平，禁止一切回能、射擊、吸寶石！
	if current_hp <= 0: return 

	if touch_damage_cooldown > 0.0:
		touch_damage_cooldown -= delta

	if current_budget < max_budget:
		current_budget += budget_recovery_rate * delta
		current_budget = min(current_budget, max_budget)
	
	process_weapons(delta)
	process_gem_magnet(delta)

# 🧲 超流暢寶石磁鐵運動學
func process_gem_magnet(delta: float) -> void:
	if current_hp <= 0: return # 🎯【殭屍防禦哨 2】：死人不可產生重力吸引寶石
	
	var gems = get_tree().get_nodes_in_group("gem")
	var attraction_range: float = 160.0 
	var collection_range: float = 32.0  
	var magnet_speed: float = 550.0     
	
	for gem in gems:
		if is_instance_valid(gem) and not gem.is_queued_for_deletion():
			var dist = global_position.distance_to(gem.global_position)
			
			if dist <= attraction_range:
				var direction = (global_position - gem.global_position).normalized()
				gem.global_position += direction * magnet_speed * delta
			
			if dist <= collection_range:
				_collect_gem_and_level_up(gem)

# 💎 全自動經驗結算與 UI 強制重繪
func _collect_gem_and_level_up(gem: Node) -> void:
	if current_hp <= 0: return # 🎯【殭屍防禦哨 3】：死人不可吞噬寶石
	if not is_instance_valid(gem) or gem.is_queued_for_deletion(): return
	if gem.has_meta("collected"): return
	gem.set_meta("collected", true)
	
	gem.queue_free() 
	current_exp += 1
	
	if current_exp >= max_exp:
		level_up()
		
	var main_scene = get_tree().current_scene
	if main_scene and main_scene.has_method("update_ui"):
		main_scene.update_ui()

# 🎯 --- 自動化戰鬥核心引擎 ---
func process_weapons(delta: float) -> void:
	var enemies = get_tree().get_nodes_in_group("enemy")
	if enemies.is_empty(): return 
	
	var target = _get_closest_enemy(enemies)
	if not target: return
	
	if discount_sword_level > 0:
		cooldowns["sword"] -= delta
		if cooldowns["sword"] <= 0:
			fire_projectile(target, "sword")
			var base_cd = 0.6
			cooldowns["sword"] = max(0.2, base_cd - (discount_sword_level * 0.08))
			
	if rumor_wand_level > 0:
		cooldowns["wand"] -= delta
		if cooldowns["wand"] <= 0 and current_budget >= 5.0:
			current_budget -= 5.0
			fire_projectile(target, "wand")
			var base_cd = 1.0
			cooldowns["wand"] = max(0.3, base_cd - (rumor_wand_level * 0.1))

	if greatsword_level > 0:
		cooldowns["greatsword"] -= delta
		if cooldowns["greatsword"] <= 0 and current_budget >= 15.0:
			current_budget -= 15.0 
			fire_projectile(target, "greatsword")
			var base_cd = 2.5
			cooldowns["greatsword"] = max(1.0, base_cd - (greatsword_level * 0.2))

func _get_closest_enemy(enemies: Array) -> Node2D:
	var closest = null
	var min_dist = 99999.0
	for enemy in enemies:
		if is_instance_valid(enemy):
			var d = global_position.distance_to(enemy.global_position)
			if d < min_dist:
				min_dist = d
				closest = enemy
	return closest

func fire_projectile(target: Node2D, w_type: String) -> void:
	if not bullet_scene: return
	var b = bullet_scene.instantiate()
	b.global_position = global_position
	b.rotation = (target.global_position - global_position).angle()
	
	match w_type:
		"sword":
			b.damage = 3 + (discount_sword_level * 2)
			b.speed = 1200.0
			b.lifespan = 0.15 
			b.modulate = Color(0.8, 0.8, 0.8) 
			b.scale = Vector2(0.5, 2.5) 
		"greatsword":
			b.damage = 15 + (greatsword_level * 5)
			b.speed = 500.0
			b.lifespan = 0.35 
			b.modulate = Color(1.0, 0.4, 0.1) 
			b.scale = Vector2(3.0, 4.0) 
		"wand":
			b.damage = 4 + (rumor_wand_level * 2)
			b.speed = 800.0
			b.lifespan = 2.0 
			b.modulate = Color(0.2, 0.8, 1.0) 
			b.scale = Vector2(1.0, 1.0) 

	get_parent().add_child(b)

func _physics_process(delta: float) -> void:
	if current_hp <= 0: return # 🎯【殭屍防禦哨 4】：死人不可移動
	
	var input_direction := Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
	if input_direction != Vector2.ZERO:
		velocity = velocity.move_toward(input_direction * max_speed, acceleration * delta)
	else:
		velocity = velocity.move_toward(Vector2.ZERO, friction * delta)
	move_and_slide()

func recalculate_stats() -> void:
	max_hp = BASE_MAX_HP
	max_speed = BASE_MAX_SPEED
	budget_recovery_rate = BASE_BUDGET_RECOVERY_RATE
	
	discount_sword_level = 0
	greatsword_level = 0
	rumor_wand_level = 0 
	
	for item in inventory_items:
		if item == null: continue
		max_hp += item.hp_modifier
		max_speed += item.speed_modifier
		budget_recovery_rate += item.budget_regen_modifier
		
		var path = item.resource_path.to_lower()
		var w_type = item.weapon_type if "weapon_type" in item else 0
		var gain = item.weapon_level_gain if "weapon_level_gain" in item else 1
		if gain <= 0: gain = 1
		
		if w_type == 1 or "discount" in path or "sword" in path or "coupon" in path:
			if "great" in path: greatsword_level += gain
			else: discount_sword_level += gain
		elif w_type == 2 or "great" in path:
			greatsword_level += gain
		elif w_type == 3 or "rumor" in path or "wand" in path or "gossip" in path:
			rumor_wand_level += gain

	max_hp = max(1, max_hp)
	max_speed = max(60.0, max_speed)
	current_hp = min(current_hp, max_hp)
	weapon_level = rumor_wand_level

func level_up() -> void:
	if current_hp <= 0: return # 🎯【殭屍防禦哨 5】：死人絕對禁止原地復活！
	
	current_exp = 0
	max_exp += 2
	player_level += 1
	current_hp = max_hp
	show_level_up_text()
	recalculate_stats()

	var main_scene = get_tree().current_scene
	if main_scene and main_scene.has_method("update_ui"):
		main_scene.update_ui()

func show_level_up_text() -> void:
	if showing_level_up or not level_up_label: return
	showing_level_up = true
	level_up_label.text = "LEVEL UP!"
	level_up_label.visible = true
	
	var tween = create_tween()
	tween.tween_property(level_up_label, "position:y", level_up_label.position.y - 40, 1.0).set_trans(Tween.TRANS_SINE)
	tween.parallel().tween_property(level_up_label, "modulate:a", 0.0, 1.0)
	tween.tween_callback(func():
		level_up_label.visible = false
		level_up_label.position.y += 40
		level_up_label.modulate.a = 1.0
		showing_level_up = false
	)

func _on_hurt_box_body_entered(body: Node2D) -> void:
	if current_hp <= 0: return # 🎯【殭屍防禦哨 6】：死人不會再受到二次傷害
	
	if body.is_in_group("enemy") and touch_damage_cooldown <= 0.0:
		current_hp -= 1
		touch_damage_cooldown = 0.5 
		
		if player_sprite:
			var tween = create_tween()
			tween.tween_property(player_sprite, "modulate", Color(1, 0.2, 0.2), 0.08)
			tween.tween_property(player_sprite, "modulate", Color(1, 1, 1), 0.08)
		
		var main_scene = get_tree().current_scene
		if main_scene and main_scene.has_method("update_ui"):
			main_scene.update_ui()

func _on_pickup_area_body_entered(body: Node2D) -> void:
	if body.is_in_group("gem"): _collect_gem_and_level_up(body)
func _on_pickup_area_area_entered(area: Area2D) -> void:
	if area.is_in_group("gem"): _collect_gem_and_level_up(area)
