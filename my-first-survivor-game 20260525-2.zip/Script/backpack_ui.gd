# res://Script/backpack_ui.gd
extends Control
class_name BackpackUI

const CELL_SIZE: int = 32
const GRID_WIDTH: int = 6
const GRID_HEIGHT: int = 4

var grid_matrix: Array = []
var grabbed_item: InventoryItemUI = null
var unlocked_width: int = 3
var unlocked_height: int = 3

func _ready() -> void:
	add_to_group("backpack_ui")
	_initialize_grid_matrix()
	process_mode = Node.PROCESS_MODE_ALWAYS
	queue_redraw()

func _get_hovered_cell() -> Vector2i:
	if not grabbed_item: return Vector2i(-1, -1)
	var local_mouse = get_local_mouse_position()
	var top_left = local_mouse - (grabbed_item.size / 2.0)
	var grid_x = int(floor((top_left.x + CELL_SIZE / 2.0) / float(CELL_SIZE)))
	var grid_y = int(floor((top_left.y + CELL_SIZE / 2.0) / float(CELL_SIZE)))
	return Vector2i(grid_x, grid_y)

func _draw() -> void:
	draw_rect(Rect2(0, 0, GRID_WIDTH * CELL_SIZE, GRID_HEIGHT * CELL_SIZE), Color(0.05, 0.05, 0.05, 0.95))
	for x in range(GRID_WIDTH):
		for y in range(GRID_HEIGHT):
			var cell_rect = Rect2(x * CELL_SIZE, y * CELL_SIZE, CELL_SIZE, CELL_SIZE)
			if x < unlocked_width and y < unlocked_height:
				draw_rect(cell_rect, Color(0.18, 0.18, 0.18, 1.0), true)
				draw_rect(cell_rect, Color(0.4, 0.4, 0.4, 0.4), false, 1.0)
			else:
				draw_rect(cell_rect, Color(0.35, 0.05, 0.05, 0.85), true)
				draw_rect(cell_rect, Color(0.6, 0.1, 0.1, 0.5), false, 1.0)
				draw_line(Vector2(x*CELL_SIZE + 6, y*CELL_SIZE + 6), Vector2((x+1)*CELL_SIZE - 6, (y+1)*CELL_SIZE - 6), Color(0.5, 0.1, 0.1, 0.6), 2.0)

	if grabbed_item and is_instance_valid(grabbed_item):
		var target_cell = _get_hovered_cell()
		var can_place = _can_place_item(grabbed_item, target_cell.x, target_cell.y)
		var highlight_color = Color(0.2, 0.8, 0.2, 0.4) if can_place else Color(0.8, 0.2, 0.2, 0.4)
		
		var data = grabbed_item.item_data
		for x in range(data.width):
			for y in range(data.height):
				var cx = target_cell.x + x
				var cy = target_cell.y + y
				if cx >= 0 and cx < GRID_WIDTH and cy >= 0 and cy < GRID_HEIGHT:
					var h_rect = Rect2(cx * CELL_SIZE, cy * CELL_SIZE, CELL_SIZE, CELL_SIZE)
					draw_rect(h_rect, highlight_color, true)

func sync_grid_expansion_by_wave(wave: int) -> void:
	var expansion_map = [
		Vector2i(3, 3), Vector2i(4, 3), Vector2i(4, 4), Vector2i(5, 4), Vector2i(6, 4)
	]
	var index = clamp(wave - 1, 0, 4)
	unlocked_width = expansion_map[index].x
	unlocked_height = expansion_map[index].y
	queue_redraw()

func _initialize_grid_matrix() -> void:
	grid_matrix.clear()
	for x in range(GRID_WIDTH):
		var column = []
		for y in range(GRID_HEIGHT):
			column.append(null)
		grid_matrix.append(column)

func _process(_delta: float) -> void:
	if grabbed_item and is_instance_valid(grabbed_item):
		grabbed_item.position = get_local_mouse_position() - (grabbed_item.size / 2.0)
		queue_redraw() 

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.pressed:
		var local_mouse_pos = get_local_mouse_position()
		var target_cell = _get_hovered_cell()
		
		if event.button_index == MOUSE_BUTTON_LEFT:
			if grabbed_item:
				if _can_place_item(grabbed_item, target_cell.x, target_cell.y):
					_place_item(grabbed_item, target_cell.x, target_cell.y)
			else:
				var exact_click_cell = Vector2i(local_mouse_pos / float(CELL_SIZE))
				if _is_within_bounds(exact_click_cell.x, exact_click_cell.y):
					var clicked_node = grid_matrix[exact_click_cell.x][exact_click_cell.y]
					if clicked_node:
						_pickup_item_at(exact_click_cell.x, exact_click_cell.y)
						
		elif event.button_index == MOUSE_BUTTON_RIGHT:
			if grabbed_item:
				print("🗑️ Item discarded to prevent soft-lock!")
				grabbed_item.queue_free()
				grabbed_item = null
				
				var main_scene = get_tree().current_scene
				if main_scene and main_scene.wave_completed and main_scene.has_method("start_next_wave"):
					get_tree().paused = false
					main_scene.start_next_wave()

func _can_place_item(item_ui: InventoryItemUI, col: int, row: int) -> bool:
	var data = item_ui.item_data
	for x in range(data.width):
		for y in range(data.height):
			var check_col = col + x
			var check_row = row + y
			if check_col < 0 or check_col >= unlocked_width or check_row < 0 or check_row >= unlocked_height:
				return false 
			if grid_matrix[check_col][check_row] != null and grid_matrix[check_col][check_row] != item_ui:
				return false 
	return true

func _is_within_bounds(col: int, row: int) -> bool:
	return col >= 0 and col < unlocked_width and row >= 0 and row < unlocked_height

func _place_item(item_ui: InventoryItemUI, col: int, row: int) -> void:
	var data = item_ui.item_data
	for x in range(data.width):
		for y in range(data.height):
			grid_matrix[col + x][row + y] = item_ui 
			
	item_ui.grid_position = Vector2i(col, row)
	item_ui.set_grabbed_visual(false)
	item_ui.position = Vector2(col * CELL_SIZE, row * CELL_SIZE)
	grabbed_item = null
	
	_sync_to_player_backend()
	
	var main_scene = get_tree().current_scene
	if main_scene and main_scene.wave_completed and main_scene.has_method("start_next_wave"):
		get_tree().paused = false
		main_scene.start_next_wave()

func _pickup_item_at(col: int, row: int) -> void:
	var target_node = grid_matrix[col][row]
	if not target_node: return
	grabbed_item = target_node
	for x in range(GRID_WIDTH):
		for y in range(GRID_HEIGHT):
			if grid_matrix[x][y] == target_node:
				grid_matrix[x][y] = null
	grabbed_item.grid_position = Vector2i(-1, -1)
	grabbed_item.set_grabbed_visual(true)
	_sync_to_player_backend()

func _sync_to_player_backend() -> void:
	var player = get_tree().get_first_node_in_group("player")
	if player and is_instance_valid(player):
		var unique_items: Array[ItemData] = []
		for x in range(GRID_WIDTH):
			for y in range(GRID_HEIGHT):
				var node = grid_matrix[x][y]
				if node and is_instance_valid(node):
					var data = node.item_data
					if data and not unique_items.has(data):
						unique_items.append(data)
		player.inventory_items = unique_items
		player.recalculate_stats()

func spawn_floating_item(data: ItemData) -> void:
	# 🎯 【全新修復】：如果手上已經抓著別的道具（比如玩家按錯按鈕），先將舊的徹底銷毀！
	if grabbed_item and is_instance_valid(grabbed_item):
		grabbed_item.queue_free()
		grabbed_item = null
		
	var item_ui_scene = preload("res://Scene/inventory_item_ui.tscn")
	if item_ui_scene:
		var item_ui = item_ui_scene.instantiate()
		add_child(item_ui)
		var unique_data = data.duplicate()
		item_ui.initialize(unique_data)
		item_ui.set_grabbed_visual(true)
		grabbed_item = item_ui
