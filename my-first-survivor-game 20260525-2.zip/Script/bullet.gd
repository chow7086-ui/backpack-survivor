# res://Script/bullet.gd
extends Area2D

@export var damage: int = 5
@export var speed: float = 900.0
# 🎯 【全新加入】：子彈壽命！近戰武器揮出去 0.15 秒就會消失，遠程武器可以飛 2 秒
@export var lifespan: float = 2.0 

@onready var damage_number_scene = preload("res://Scene/damage_number.tscn")

func _ready() -> void:
	body_entered.connect(_on_target_entered)
	area_entered.connect(_on_target_entered)
	
	# 🎯 啟動自毀倒數機制（模擬近戰揮砍的殘影消失）
	var timer = get_tree().create_timer(lifespan)
	timer.timeout.connect(queue_free)

func _physics_process(delta: float) -> void:
	position += Vector2.RIGHT.rotated(rotation) * speed * delta

func _on_target_entered(target: Node) -> void:
	if target.is_in_group("enemy"):
		if target.has_method("take_damage"):
			target.take_damage(damage)
			
		if damage_number_scene:
			var num = damage_number_scene.instantiate()
			get_tree().current_scene.add_child(num)
			num.set_text_and_tween(str(damage), target.global_position + Vector2(0, -40))
			
		queue_free()
