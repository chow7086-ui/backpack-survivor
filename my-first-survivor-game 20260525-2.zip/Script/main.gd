# res://Script/main.gd
extends Node2D

@export var enemy_scene: PackedScene = preload("res://Scene/enemy.tscn")
@export var fast_enemy_scene: PackedScene = preload("res://Scene/fast_enemy.tscn")
@export var gem_scene: PackedScene = preload("res://Scene/gem.tscn")
@export var spam_window_scene: PackedScene = preload("res://Scene/spam_window.tscn")

var score: int = 0
var wave_completed: bool = true
var wave_number: int = 0
var current_choices: Array[ItemData] = [null, null, null]
var pending_action: String = "" 
# 1. 將頂部的 score 變數換成 money
var money: int = 0  # 🎯 帳戶餘額（比特幣 / 薪水）

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS 
	
	var t_node = get_node_or_null("Timer")
	var wt_node = get_node_or_null("WaveTimer")
	var st_node = get_node_or_null("SpamTimer")
	var p_node = get_node_or_null("Player") if has_node("Player") else get_node_or_null("player")
	
	if t_node: t_node.process_mode = Node.PROCESS_MODE_PAUSABLE
	if wt_node: wt_node.process_mode = Node.PROCESS_MODE_PAUSABLE
	if st_node: st_node.process_mode = Node.PROCESS_MODE_PAUSABLE
	if p_node: p_node.process_mode = Node.PROCESS_MODE_PAUSABLE
	
	if t_node: t_node.timeout.connect(spawn_enemy)
	if wt_node: wt_node.timeout.connect(wave_over)
	if st_node: st_node.timeout.connect(spawn_spam_call)
	
	if has_node("CanvasLayer/PauseMenu/BtnContinue"): $CanvasLayer/PauseMenu/BtnContinue.pressed.connect(_on_btn_continue_pressed)
	if has_node("CanvasLayer/PauseMenu/BtnRestart"): $CanvasLayer/PauseMenu/BtnRestart.pressed.connect(_on_btn_restart_system_pressed)
	if has_node("CanvasLayer/PauseMenu/BtnQuit"): $CanvasLayer/PauseMenu/BtnQuit.pressed.connect(_on_btn_quit_pressed)
	
	if has_node("CanvasLayer/ConfirmBox/BtnConfirmYes"): $CanvasLayer/ConfirmBox/BtnConfirmYes.pressed.connect(_on_btn_confirm_yes_pressed)
	if has_node("CanvasLayer/ConfirmBox/BtnConfirmNo"): $CanvasLayer/ConfirmBox/BtnConfirmNo.pressed.connect(_on_btn_confirm_no_pressed)
	
	if has_node("CanvasLayer/UpgradeMenu"): $CanvasLayer/UpgradeMenu.hide()
	if has_node("CanvasLayer/PauseMenu"): $CanvasLayer/PauseMenu.hide()
	if has_node("CanvasLayer/ConfirmBox"): $CanvasLayer/ConfirmBox.hide()
	
	present_initial_weapons()
	update_ui()

func _process(_delta: float) -> void:
	if not wave_completed and has_node("CanvasLayer/TimeLabel") and has_node("WaveTimer"):
		var time_left = int(ceil($WaveTimer.time_left))
		$CanvasLayer/TimeLabel.text = "WAVE " + str(wave_number) + " : " + str(time_left)

func present_initial_weapons() -> void:
	if has_node("CanvasLayer/TimeLabel"):
		$CanvasLayer/TimeLabel.text = "CHOOSE YOUR STARTING WEAPON"
	
	var initial_weapon_pool = [
		"res://Resource/item_discount_sword.tres",
		"res://Resource/item_greatsword.tres",
		"res://Resource/item_rumor_wand.tres"
	]
	
	if has_node("CanvasLayer/UpgradeMenu"): $CanvasLayer/UpgradeMenu.show()
		
	var backpack = get_tree().get_first_node_in_group("backpack_ui")
	if backpack:
		if backpack.has_method("sync_grid_expansion_by_wave"):
			backpack.sync_grid_expansion_by_wave(1)
		backpack.show()
	
	for i in range(3):
		if i < initial_weapon_pool.size():
			var item_res = load(initial_weapon_pool[i])
			current_choices[i] = item_res
			
			var btn = null
			if i == 0: btn = get_node_or_null("CanvasLayer/UpgradeMenu/BtnHp")
			elif i == 1: btn = get_node_or_null("CanvasLayer/UpgradeMenu/BtnSpeed")
			elif i == 2: btn = get_node_or_null("CanvasLayer/UpgradeMenu/BtnWeapon")
			
			if btn and item_res:
				btn.text = item_res.item_name
				
	get_tree().paused = true

func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed:
		if has_node("CanvasLayer/ConfirmBox") and $CanvasLayer/ConfirmBox.visible:
			return 
			
		if event.keycode == KEY_R:
			_on_btn_restart_system_pressed()
			
		if event.keycode == KEY_I and not wave_completed:
			var backpack = get_tree().get_first_node_in_group("backpack_ui")
			if backpack:
				if backpack.visible:
					backpack.hide()
					get_tree().paused = false
				else:
					backpack.show()
					get_tree().paused = true
				update_ui()

		if event.keycode == KEY_ESCAPE and not wave_completed:
			var pause_menu = get_node_or_null("CanvasLayer/PauseMenu")
			if pause_menu:
				if pause_menu.visible:
					_on_btn_continue_pressed()
				else:
					pause_menu.show()
					get_tree().paused = true

# 🎯 【修復暫停 Bug】：點擊繼續遊戲時，進行防禦性狀態攔截！
func _on_btn_continue_pressed() -> void:
	if has_node("CanvasLayer/PauseMenu"): $CanvasLayer/PauseMenu.hide()
	
	var backpack = get_tree().get_first_node_in_group("backpack_ui")
	# 🔥 關鍵核心：如果彈窗關閉了，但背包介面依然開著，強制維持遊戲暫停，絕不穿幫！
	if backpack and backpack.visible:
		get_tree().paused = true
	else:
		get_tree().paused = false

func _on_btn_restart_system_pressed() -> void:
	pending_action = "restart"
	if has_node("CanvasLayer/ConfirmBox/ConfirmLabel"):
		$CanvasLayer/ConfirmBox/ConfirmLabel.text = "Are you sure you want to RESTART?"
	if has_node("CanvasLayer/PauseMenu"): $CanvasLayer/PauseMenu.hide()
	if has_node("CanvasLayer/ConfirmBox"): $CanvasLayer/ConfirmBox.show()

func _on_btn_quit_pressed() -> void:
	pending_action = "quit"
	if has_node("CanvasLayer/ConfirmBox/ConfirmLabel"):
		$CanvasLayer/ConfirmBox/ConfirmLabel.text = "Are you sure you want to QUIT?"
	if has_node("CanvasLayer/PauseMenu"): $CanvasLayer/PauseMenu.hide()
	if has_node("CanvasLayer/ConfirmBox"): $CanvasLayer/ConfirmBox.show()

func _on_btn_confirm_yes_pressed() -> void:
	if has_node("CanvasLayer/ConfirmBox"): $CanvasLayer/ConfirmBox.hide()
	if pending_action == "restart":
		get_tree().paused = false
		get_tree().reload_current_scene()
	elif pending_action == "quit":
		get_tree().quit()
	pending_action = ""

func _on_btn_confirm_no_pressed() -> void:
	if has_node("CanvasLayer/ConfirmBox"): $CanvasLayer/ConfirmBox.hide()
	pending_action = ""
	if has_node("CanvasLayer/PauseMenu"): $CanvasLayer/PauseMenu.show()

func spawn_enemy() -> void:
	if wave_completed or not enemy_scene: return
	var spawn_count = randi_range(3, 6)
	var p_node = get_tree().get_first_node_in_group("player")
	if not p_node: return
	
	for i in range(spawn_count):
		var chosen_scene = enemy_scene if randf() > 0.4 else fast_enemy_scene
		if not chosen_scene: continue
		var enemy = chosen_scene.instantiate()
		enemy.process_mode = Node.PROCESS_MODE_PAUSABLE
		enemy.add_to_group("enemy") 
		
		var random_angle = randf_range(0, 2 * PI)
		var spawn_distance = randf_range(500, 700) 
		var spawn_position = p_node.global_position + Vector2.RIGHT.rotated(random_angle) * spawn_distance
		enemy.global_position = spawn_position
		add_child(enemy)

# 2. 修改 add_score 函式，改名為增加金錢
func add_money(amount: int, death_position: Vector2) -> void:
	money += amount # 🎯 擊殺怪物直接獲得加班費！
	update_ui()
	if gem_scene:
		var new_gem = gem_scene.instantiate()
		new_gem.global_position = death_position
		call_deferred("add_child", new_gem)

# 3. 🛡️ 防禦性相容：如果其他怪物腳本還在呼叫 add_score，自動導流到 add_money
func add_score(death_position: Vector2) -> void:
	add_money(1, death_position)

# 4. 更新 UI 顯示資訊
func update_ui() -> void:
	var player = get_tree().get_first_node_in_group("player")
	if player and is_instance_valid(player) and has_node("CanvasLayer/GameUI"):
		var hp_bar = player.get_node_or_null("HPBar")
		var budget_bar = player.get_node_or_null("BudgetBar")
		
		if player.current_hp <= 0:
			if hp_bar: hp_bar.value = 0
			game_over()
			return
			
		if hp_bar:
			hp_bar.max_value = player.max_hp
			hp_bar.value = player.current_hp
		if budget_bar:
			budget_bar.max_value = player.max_budget
			budget_bar.value = player.current_budget
		
		var exp_text = "EXP: " + str(player.current_exp) + "/" + str(player.max_exp)
		# 🎯 【UI 升級】：將 Score 替換為極具生產力的比特幣資產圖標！
		var money_text = "Bitcoin: $" + str(money)
		var stat_text = "Speed: " + str(int(player.max_speed)) + " | \nBudget Regen: " + str(int(player.budget_recovery_rate)) + "/s | \nLv: " + str(player.player_level)
		$CanvasLayer/GameUI.text = exp_text + "\n" + money_text + "\n[ WORKPLACE INCOME ] " + stat_text
	elif not player:
		game_over()

# 5. 死亡結算畫面同步更新
func game_over() -> void:
	wave_completed = true 
	if has_node("Timer"): $Timer.stop() 
	if has_node("WaveTimer"): $WaveTimer.stop() 
	if has_node("SpamTimer"): $SpamTimer.stop()
	if has_node("CanvasLayer/TimeLabel"):
		$CanvasLayer/TimeLabel.text = "BANKRUPTCY (GAME OVER)\nTotal Assets: $" + str(money)
	for enemy in get_tree().get_nodes_in_group("enemy"): enemy.queue_free()
	for gem in get_tree().get_nodes_in_group("gem"): gem.queue_free()

func wave_over() -> void:
	wave_completed = true
	if has_node("Timer"): $Timer.stop()
	if has_node("SpamTimer"): $SpamTimer.stop()
	if has_node("CanvasLayer/TimeLabel"):
		$CanvasLayer/TimeLabel.text = "WAVE " + str(wave_number) + " COMPLETED!"
	for enemy in get_tree().get_nodes_in_group("enemy") : enemy.queue_free()
	
	var item_pool = [
		"res://Resource/item_pizza_coupon.tres",
		"res://Resource/item_paid_leave.tres",
		"res://Resource/item_overtime_cauldron.tres",
		"res://Resource/item_tax_calculator.tres"
	]
	
	item_pool.shuffle()
	if has_node("CanvasLayer/UpgradeMenu"): $CanvasLayer/UpgradeMenu.show()
	var backpack = get_tree().get_first_node_in_group("backpack_ui")
	if backpack: 
		if backpack.has_method("sync_grid_expansion_by_wave"):
			backpack.sync_grid_expansion_by_wave(wave_number + 1)
		backpack.show()
	
	for i in range(3):
		var item_path = item_pool[i]
		var item_res = load(item_path)
		current_choices[i] = item_res
		
		var btn = null
		if i == 0: btn = get_node_or_null("CanvasLayer/UpgradeMenu/BtnHp")
		elif i == 1: btn = get_node_or_null("CanvasLayer/UpgradeMenu/BtnSpeed")
		elif i == 2: btn = get_node_or_null("CanvasMenu/BtnWeapon") if has_node("CanvasMenu/BtnWeapon") else get_node_or_null("CanvasLayer/UpgradeMenu/BtnWeapon")
		
		if btn and item_res:
			btn.text = item_res.item_name

	get_tree().paused = true 

func start_next_wave() -> void:
	wave_number += 1
	wave_completed = false
	if has_node("CanvasLayer/UpgradeMenu"): $CanvasLayer/UpgradeMenu.hide()
	
	var backpack = get_tree().get_first_node_in_group("backpack_ui")
	if backpack: backpack.hide()
	
	if has_node("Timer"): $Timer.start()
	if has_node("SpamTimer"): $SpamTimer.start()
	if has_node("WaveTimer"): $WaveTimer.start(30.0)
	
	for gem in get_tree().get_nodes_in_group("gem"): gem.queue_free()
		
	var player = get_tree().get_first_node_in_group("player")
	if player and is_instance_valid(player):
		player.current_budget = player.max_budget 
			
	update_ui()

func _on_btn_hp_pressed() -> void:
	var backpack = get_tree().get_first_node_in_group("backpack_ui")
	if backpack and current_choices[0]:
		backpack.spawn_floating_item(current_choices[0])

func _on_btn_speed_pressed() -> void:
	var backpack = get_tree().get_first_node_in_group("backpack_ui")
	if backpack and current_choices[1]:
		backpack.spawn_floating_item(current_choices[1])

func _on_btn_weapon_pressed() -> void:
	var backpack = get_tree().get_first_node_in_group("backpack_ui")
	if backpack and current_choices[2]:
		backpack.spawn_floating_item(current_choices[2])

func spawn_spam_call() -> void:
	if wave_completed or not spam_window_scene: return
	var player = get_tree().get_first_node_in_group("player")
	if player and is_instance_valid(player):
		var window = spam_window_scene.instantiate()
		var offset_x = randf_range(-250, 250)
		var offset_y = randf_range(-150, 150)
		window.global_position = player.global_position + Vector2(offset_x, offset_y)
		add_child(window)
