extends Label

func set_text_and_tween(text_val: String, position_val: Vector2) -> void:
	text = text_val
	global_position = position_val
	
	# 設定縮放中心點為文字正中央
	pivot_offset = size / 2
	
	# 🚀 華麗的補間動畫
	var tween = create_tween()
	
	# 1. 向上飄移並微微放大
	var target_y = position.y - 60.0
	tween.tween_property(self, "position:y", target_y, 0.4).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	tween.parallel().tween_property(self, "scale", Vector2(1.2, 1.2), 0.2).set_trans(Tween.TRANS_BACK)
	
	# 2. 後半段平滑變透明消失
	tween.tween_property(self, "modulate:a", 0.0, 0.2).set_delay(0.2)
	
	# 3. 消失後自動銷毀
	tween.tween_callback(queue_free)
