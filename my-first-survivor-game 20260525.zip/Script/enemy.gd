extends CharacterBody2D

@export var base_speed: float = 105.0

var speed: float
var max_hp: int
var current_hp: int
@onready var sprite: Sprite2D = $Sprite2D
@onready var separation_area: Area2D = get_node_or_null("SeparationArea")

var wobble_timer: float = randf_range(0.0, 10.0) 
var player: Node2D = null
var random_speed_modifier: float = 1.0

func _ready() -> void:
	player = get_tree().get_first_node_in_group("player")
	random_speed_modifier = randf_range(0.85, 1.15)
	var size_modifier = randf_range(0.8, 1.2)
	
	speed = base_speed * (1.0 / size_modifier) 
	max_hp = int(5 * randf_range(1.0, 3.0)) 
	current_hp = max_hp
	sprite.scale = Vector2(size_modifier, size_modifier)

func _physics_process(delta: float) -> void:
	if is_instance_valid(player):
		wobble_timer += delta * 8.0 
		var target_dir = (player.global_position - global_position).normalized()
		var separation_dir = _get_separation_vector()
		var wobble_vector = target_dir.orthogonal() * sin(wobble_timer) * 0.25
		
		var final_dir = (target_dir * 0.5 + separation_dir * 0.35 + wobble_vector * 0.15).normalized()
		velocity = final_dir * (speed * random_speed_modifier)
		move_and_slide()

func _get_separation_vector() -> Vector2:
	var steer = Vector2.ZERO
	if not is_instance_valid(separation_area):
		return steer
		
	var neighbors = separation_area.get_overlapping_bodies()
	var count = 0
	
	for neighbor in neighbors:
		if neighbor.is_in_group("enemy") and neighbor != self:
			var diff = global_position - neighbor.global_position
			var distance = diff.length()
			
			if distance < 1.0:
				steer += Vector2(randf_range(-1, 1), randf_range(-1, 1)).normalized()
			else:
				steer += diff.normalized() / distance
			count += 1
			
	if count > 0:
		steer /= count
		
	return steer.normalized()

func take_damage(amount: int) -> void:
	current_hp -= amount
	
	var original_modulate = sprite.modulate
	var tween = create_tween()
	tween.tween_property(sprite, "modulate", Color(2.5, 0.4, 0.4), 0.07)
	tween.tween_property(sprite, "modulate", original_modulate, 0.07)
	
	if current_hp <= 0:
		set_physics_process(false)
		if has_node("CollisionShape2D"): $CollisionShape2D.queue_free()
		if get_node_or_null("separationArea"): $separationArea.queue_free()
		if get_node_or_null("SeparationArea"): $SeparationArea.queue_free()
		
		if get_tree().current_scene.has_method("add_score"):
			get_tree().current_scene.add_score(global_position)
			
		var die_tween = create_tween()
		die_tween.tween_property(sprite, "modulate", Color(4.0, 4.0, 4.0, 1.0), 0.1)
		
		var target_y = global_position.y - 80.0
		die_tween.parallel().tween_property(self, "global_position:y", target_y, 0.3).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
		die_tween.parallel().tween_property(sprite, "modulate:a", 0.0, 0.3)
		die_tween.tween_callback(queue_free)
