# res://Script/item_data.gd
extends Resource
class_name ItemData # 🎯 讓這個資源變成 Godot 編輯器內建的類型

@export var item_name: String = "未命名道具"
@export_multiline var description: String = "道具敘述"
@export var icon: Texture2D # 道具的圖片

# 🧮 背包英雄的空間幾何：定義這個道具佔用幾乘幾的格子
@export var width: int = 1  # 寬度（佔幾格）
@export var height: int = 1 # 高度（佔幾格）

# 💰 城市設計的臨時貨幣：商店買這座「建築/道具」要花多少寶石
@export var buy_cost: int = 10 

# 🏢 城市與 RPG 屬性連動因子 (對應你的 GDD 表格)
@export var hp_modifier: int = 0               # 影響血量上限
@export var speed_modifier: float = 0.0         # 影響移動速度
@export var budget_regen_modifier: float = 0.0  # 影響每秒精力回復 (Budget)

# ⚔️ 武器分類流派解鎖 (1: 普攻折價卷, 2: 大劍, 3: 魔杖)
@export_enum("None", "DiscountSword", "Greatsword", "RumorWand") var weapon_type: int = 0
@export var weapon_level_gain: int = 0          # 增加對應武器的等級extends Node
