extends Area2D

var is_dead: bool = false
@onready var color_rect: ColorRect = $ColorRect # 抓到你的視窗色塊

func _ready() -> void:
	# 確保自己屬於 enemy 群組，讓子彈會自動瞄準
	add_to_group("enemy")

# 🎯 魔改受傷機制：訊息視窗無視傷害數值，一槍必殺！
func take_damage(_amount: int) -> void:
	if is_dead:
		return
	is_dead = true
	
	# 1. 立刻關閉碰撞，防止被其他子彈重複擊中導致重複撥放動畫
	set_deferred("monitoring", false)
	set_deferred("monitorable", false)
	
	# 2. 🎯 【全新新增】：Teams 訊息爆裂消失特效
	var die_tween = create_tween()
	
	# 一瞬間變成耀眼的白光/強烈紅光
	die_tween.tween_property(color_rect, "modulate", Color(4.0, 1.5, 1.5, 1.0), 0.05)
	
	# 隨後 0.15 秒內，一邊極速縮小到 0，一邊變透明
	die_tween.parallel().tween_property(self, "scale", Vector2(0.0, 0.0), 0.15).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_IN)
	die_tween.parallel().tween_property(color_rect, "modulate:a", 0.0, 0.15)
	
	# 動態播完，視窗「已讀不回」圓滿刪除！
	die_tween.tween_callback(queue_free)
