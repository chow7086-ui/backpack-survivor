# res://Script/main.gd
extends Node2D

@export var enemy_scene: PackedScene = preload("res://Scene/enemy.tscn")
@export var fast_enemy_scene: PackedScene = preload("res://Scene/fast_enemy.tscn")
@export var gem_scene: PackedScene = preload("res://Scene/gem.tscn")
@export var spam_window_scene: PackedScene = preload("res://Scene/spam_window.tscn")

var score: int = 0
var wave_completed: bool = false
var wave_number: int = 1
var current_choices: Array[ItemData] = [null, null, null]
var pending_action: String = "" 

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS # 主程式維持最高權限 (負責聽鍵盤)
	
	# 🎯 【修復 Bug】：強制把遊戲世界裡的活物降級，確保 get_tree().paused 會凍結牠們！
	$Timer.process_mode = Node.PROCESS_MODE_PAUSABLE
	$WaveTimer.process_mode = Node.PROCESS_MODE_PAUSABLE
	$SpamTimer.process_mode = Node.PROCESS_MODE_PAUSABLE
	if has_node("Player"):
		$Player.process_mode = Node.PROCESS_MODE_PAUSABLE
	
	$Timer.timeout.connect(spawn_enemy)
	$WaveTimer.timeout.connect(wave_over)
	$SpamTimer.timeout.connect(spawn_spam_call)
	
	if has_node("CanvasLayer/PauseMenu/BtnContinue"): $CanvasLayer/PauseMenu/BtnContinue.pressed.connect(_on_btn_continue_pressed)
	if has_node("CanvasLayer/PauseMenu/BtnRestart"): $CanvasLayer/PauseMenu/BtnRestart.pressed.connect(_on_btn_restart_system_pressed)
	if has_node("CanvasLayer/PauseMenu/BtnQuit"): $CanvasLayer/PauseMenu/BtnQuit.pressed.connect(_on_btn_quit_pressed)
	
	if has_node("CanvasLayer/ConfirmBox/BtnConfirmYes"): $CanvasLayer/ConfirmBox/BtnConfirmYes.pressed.connect(_on_btn_confirm_yes_pressed)
	if has_node("CanvasLayer/ConfirmBox/BtnConfirmNo"): $CanvasLayer/ConfirmBox/BtnConfirmNo.pressed.connect(_on_btn_confirm_no_pressed)
	
	$CanvasLayer/UpgradeMenu.hide()
	if has_node("CanvasLayer/PauseMenu"): $CanvasLayer/PauseMenu.hide()
	if has_node("CanvasLayer/ConfirmBox"): $CanvasLayer/ConfirmBox.hide()
	
	var backpack = get_tree().get_first_node_in_group("backpack_ui")
	if backpack:
		# 🎯 開局強制對齊 Wave 1 的網格 (3x3)
		backpack.sync_grid_expansion_by_wave(wave_number) 
		backpack.hide()
		
	wave_completed = false
	$Timer.start()
	$WaveTimer.start(30.0)
	$SpamTimer.start()
	update_ui()

func _process(_delta: float) -> void:
	if not wave_completed:
		var time_left = int(ceil($WaveTimer.time_left))
		$CanvasLayer/TimeLabel.text = "WAVE " + str(wave_number) + " : " + str(time_left)

func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed:
		if $CanvasLayer/ConfirmBox.visible:
			return # 二次確認視窗亮起時，封鎖其餘一切干擾
			
		if event.keycode == KEY_R:
			_on_btn_restart_system_pressed()
			
		if event.keycode == KEY_I and not wave_completed:
			var backpack = get_tree().get_first_node_in_group("backpack_ui")
			if backpack:
				if backpack.visible:
					backpack.hide()
					get_tree().paused = false
				else:
					backpack.show()
					get_tree().paused = true
				update_ui()

		if event.keycode == KEY_ESCAPE and not wave_completed:
			var pause_menu = get_node_or_null("CanvasLayer/PauseMenu")
			if pause_menu:
				if pause_menu.visible:
					_on_btn_continue_pressed()
				else:
					pause_menu.show()
					get_tree().paused = true

# =====================================================================
# 🛠️ SYSTEM CORE CONFIRMATION CODES (二次確認狀態機優化版)
# =====================================================================
func _on_btn_continue_pressed() -> void:
	if has_node("CanvasLayer/PauseMenu"): $CanvasLayer/PauseMenu.hide()
	get_tree().paused = false

func _on_btn_restart_system_pressed() -> void:
	pending_action = "restart"
	if has_node("CanvasLayer/ConfirmBox/ConfirmLabel"):
		$CanvasLayer/ConfirmBox/ConfirmLabel.text = "Are you sure you want to RESTART the game?"
	if has_node("CanvasLayer/PauseMenu"): $CanvasLayer/PauseMenu.hide()
	$CanvasLayer/ConfirmBox.show()

func _on_btn_quit_pressed() -> void:
	pending_action = "quit"
	if has_node("CanvasLayer/ConfirmBox/ConfirmLabel"):
		$CanvasLayer/ConfirmBox/ConfirmLabel.text = "Are you sure you want to QUIT to desktop?"
	if has_node("CanvasLayer/PauseMenu"): $CanvasLayer/PauseMenu.hide()
	$CanvasLayer/ConfirmBox.show()

# 🎯 【YES 退出 Bug 終結者】：獨立於暫停線程之外，點擊 YES 百分之百強制執行關閉或重開！
func _on_btn_confirm_yes_pressed() -> void:
	$CanvasLayer/ConfirmBox.hide()
	if pending_action == "restart":
		get_tree().paused = false
		get_tree().reload_current_scene()
	elif pending_action == "quit":
		print("🚪 Quit Confirmed. Destroying Game Window...")
		get_tree().quit() # 100% 關閉視窗
	pending_action = ""

func _on_btn_confirm_no_pressed() -> void:
	$CanvasLayer/ConfirmBox.hide()
	pending_action = ""
	if has_node("CanvasLayer/PauseMenu"): 
		$CanvasLayer/PauseMenu.show()

# =====================================================================
# ⚔️ COMBAT LOOP ENGINE (常規戰鬥維持不變)
# =====================================================================
func spawn_enemy() -> void:
	if wave_completed: return
	var spawn_count = randi_range(3, 6)
	for i in range(spawn_count):
		var chosen_scene = enemy_scene if randf() > 0.4 else fast_enemy_scene
		if not chosen_scene: continue
		var enemy = chosen_scene.instantiate()
		enemy.process_mode = Node.PROCESS_MODE_PAUSABLE # 🎯 新增：確保怪物會被暫停！
		var random_angle = randf_range(0, 2 * PI)
		var spawn_distance = randf_range(500, 700) 
		var spawn_position = $Player.global_position + Vector2.RIGHT.rotated(random_angle) * spawn_distance
		spawn_position += Vector2(randf_range(-50, 50), randf_range(-50, 50))
		enemy.global_position = spawn_position
		add_child(enemy)

func add_score(death_position: Vector2) -> void:
	score += 1
	update_ui()
	spawn_gem(death_position)

func spawn_gem(pos: Vector2) -> void:
	if gem_scene:
		var new_gem = gem_scene.instantiate()
		new_gem.global_position = pos
		call_deferred("add_child", new_gem)

func update_ui() -> void:
	var player = get_tree().get_first_node_in_group("player")
	if player and is_instance_valid(player):
		var hp_bar = player.get_node_or_null("HPBar")
		var budget_bar = player.get_node_or_null("BudgetBar")
		
		if player.current_hp <= 0:
			if hp_bar: hp_bar.value = 0
			game_over()
			return
			
		if hp_bar:
			hp_bar.max_value = player.max_hp
			hp_bar.value = player.current_hp
		if budget_bar:
			budget_bar.max_value = player.max_budget
			budget_bar.value = player.current_budget
		
		var exp_text = "EXP: " + str(player.current_exp) + "/" + str(player.max_exp)
		var score_text = "Score: " + str(score)
		var stat_text = "Speed: " + str(int(player.max_speed)) + " | Budget Regen: " + str(int(player.budget_recovery_rate)) + "/s | Weapon school Lv: " + str(player.weapon_level)
		$CanvasLayer/GameUI.text = exp_text + "\n" + score_text + "\n[ WORKPLACE TALENT ] " + stat_text
	else:
		game_over()

func game_over() -> void:
	wave_completed = true 
	$Timer.stop() 
	$WaveTimer.stop() 
	$SpamTimer.stop()
	$CanvasLayer/TimeLabel.text = "GAME OVER\nScore: " + str(score)
	for enemy in get_tree().get_nodes_in_group("enemy"): enemy.queue_free()
	for gem in get_tree().get_nodes_in_group("gem"): gem.queue_free()

func wave_over() -> void:
	wave_completed = true
	$Timer.stop()
	$SpamTimer.stop()
	$CanvasLayer/TimeLabel.text = "WAVE " + str(wave_number) + " COMPLETED!"
	for enemy in get_tree().get_nodes_in_group("enemy") : enemy.queue_free()
	
	var item_pool = [
		"res://Resource/item_pizza_coupon.tres",
		"res://Resource/item_paid_leave.tres",
		"res://Resource/item_overtime_cauldron.tres",
		"res://Resource/item_tax_calculator.tres",
		"res://Resource/item_kingdom_decree.tres",
		"res://Resource/item_gossip_weekly.tres",
		"res://Resource/item_task_sigil.tres",
		"res://Resource/item_expense_reimbursement.tres"
	]
	
	item_pool.shuffle()
	$CanvasLayer/UpgradeMenu.show()
	var backpack = get_tree().get_first_node_in_group("backpack_ui")
	if backpack: 
		# 🎯 核心連動：打完當前波次後，預先為下一波擴張網格土地！
		backpack.sync_grid_expansion_by_wave(wave_number + 1)
		backpack.show()
	
	for i in range(3):
		var item_path = item_pool[i]
		var item_res = load(item_path)
		current_choices[i] = item_res
		
		var btn = null
		if i == 0: btn = $CanvasLayer/UpgradeMenu/BtnHp
		elif i == 1: btn = $CanvasLayer/UpgradeMenu/BtnSpeed
		elif i == 2: btn = $CanvasLayer/UpgradeMenu/BtnWeapon
		
		if btn and item_res:
			btn.text = item_res.item_name

	get_tree().paused = true 

func start_next_wave() -> void:
	wave_number += 1
	wave_completed = false
	$CanvasLayer/UpgradeMenu.hide()
	
	var backpack = get_tree().get_first_node_in_group("backpack_ui")
	if backpack: backpack.hide()
	
	$Timer.start()
	$SpamTimer.start()
	$WaveTimer.start(30.0)
	
	for gem in get_tree().get_nodes_in_group("gem"): gem.queue_free()
		
	var player = get_tree().get_first_node_in_group("player")
	if player and is_instance_valid(player):
		player.is_burst_mode = false
		player.current_budget = player.max_budget 
		if player.has_node("AutoShootTimer"):
			player.get_node("AutoShootTimer").wait_time = 0.2
			
	update_ui()

func _on_btn_hp_pressed() -> void:
	var backpack = get_tree().get_first_node_in_group("backpack_ui")
	if backpack and current_choices[0]:
		backpack.spawn_floating_item(current_choices[0])
	$CanvasLayer/UpgradeMenu.hide()

func _on_btn_speed_pressed() -> void:
	var backpack = get_tree().get_first_node_in_group("backpack_ui")
	if backpack and current_choices[1]:
		backpack.spawn_floating_item(current_choices[1])
	$CanvasLayer/UpgradeMenu.hide()

func _on_btn_weapon_pressed() -> void:
	var backpack = get_tree().get_first_node_in_group("backpack_ui")
	if backpack and current_choices[2]:
		backpack.spawn_floating_item(current_choices[2])
	$CanvasLayer/UpgradeMenu.hide()

func spawn_spam_call() -> void:
	if wave_completed: return
	var player = get_tree().get_first_node_in_group("player")
	if player and is_instance_valid(player) and spam_window_scene:
		var window = spam_window_scene.instantiate()
		var offset_x = randf_range(-250, 250)
		var offset_y = randf_range(-150, 150)
		window.global_position = player.global_position + Vector2(offset_x, offset_y)
		add_child(window)
