# res://Script/inventory_item_ui.gd
extends Control
class_name InventoryItemUI

const CELL_SIZE: int = 32

var item_data: ItemData = null
var grid_position: Vector2i = Vector2i(-1, -1)

@onready var icon_rect: TextureRect = $Icon

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	if has_node("Icon"):
		$Icon.mouse_filter = Control.MOUSE_FILTER_IGNORE

func initialize(data: ItemData) -> void:
	item_data = data
	custom_minimum_size = Vector2(data.width * CELL_SIZE, data.height * CELL_SIZE)
	size = custom_minimum_size
	
	if icon_rect and data.icon:
		icon_rect.texture = data.icon
		# 🎯 【修復對齊 Bug】：強制圖片無視原始大小，並保持比例完美置中於格內！
		icon_rect.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		icon_rect.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		
		# 強制四邊錨點貼齊父節點邊緣
		icon_rect.anchor_left = 0.0
		icon_rect.anchor_top = 0.0
		icon_rect.anchor_right = 1.0
		icon_rect.anchor_bottom = 1.0
		icon_rect.offset_left = 0
		icon_rect.offset_top = 0
		icon_rect.offset_right = 0
		icon_rect.offset_bottom = 0
		
	queue_redraw() # 通知引擎畫底框

		# 🎨 【全新加入】：為道具畫上實體底板與邊框！
func _draw() -> void:
	if item_data:
		var rect = Rect2(0, 0, size.x, size.y)
		# 畫半透明的深藍色底板，讓它看起來像一塊「晶片」
		draw_rect(rect, Color(0.15, 0.25, 0.35, 0.85), true)
		# 畫亮藍色的外邊框
		draw_rect(rect, Color(0.4, 0.7, 0.9, 0.8), false, 2.0)

func set_grabbed_visual(grabbed: bool) -> void:
	if grabbed:
		modulate.a = 0.6
		z_index = 100 
	else:
		modulate.a = 1.0
		z_index = 1
