extends CharacterBody2D

@export var bullet_scene: PackedScene = preload("res://Scene/bullet.tscn")

# --- BASELINE CONSTANTS ---
const BASE_MAX_HP: int = 5
const BASE_MAX_SPEED: float = 300.0
const BASE_BUDGET_RECOVERY_RATE: float = 15.0

# --- MOVEMENT PHYSICS ---
@export var max_speed: float = 300.0
@export var acceleration: float = 1500.0  
@export var friction: float = 1500.0      

# --- PROGRESSION SYSTEM ---
var current_exp: int = 0
var max_exp: int = 3

# --- BACKEND INVENTORY SYSTEM ---
var inventory_items: Array[ItemData] = []

# --- WEAPON LEVEL DATABASE ---
var weapon_level: int = 1 
var discount_sword_level: int = 0
var greatsword_level: int = 0
var rumor_wand_level: int = 1

# --- JUICE & EFFECTS VARIANCE ---
var gem_timestamps: Array = []       
var dialogue_cooldown: float = 0.0   
var showing_level_up: bool = false
var is_slacking: bool = false 
var glow_tween: Tween = null

@onready var player_sprite = $Sprite2D 
@onready var level_up_label: Label = $LevelUpLabel

# --- DYNAMIC RPG ATTRIBUTES ---
var max_hp: int = BASE_MAX_HP
var current_hp: int = max_hp

@export var max_budget: float = 100.0   
var budget_recovery_rate: float = BASE_BUDGET_RECOVERY_RATE
var current_budget: float = 0.0 

# --- BURST MODE MECHANICS ---
var is_burst_mode: bool = false
var burst_timer: float = 0.0
@export var burst_duration: float = 3.0

# res://Script/player.gd 頂部變數區
var player_level: int = 1 # 🎯 【全新加入】：實體化等級追蹤，防止背包土地解鎖失控！

func _ready() -> void:
	$HurtBox.body_entered.connect(_on_hurt_box_body_entered)
	$AutoShootTimer.timeout.connect(shoot)
	
	# 🧪 ------------ BACKEND DATA TEST BENCH ------------
	# NOTE: Please verify that these file paths perfectly match your English resource names!
	var test_item_coffee = load("res://Resource/item_overtime_cauldron.tres")
	var test_item_decree = load("res://Resource/item_kingdom_decree.tres")
	
	if test_item_coffee:
		inventory_items.append(test_item_coffee) 
	if test_item_decree:
		inventory_items.append(test_item_decree) 
		
	recalculate_stats()
	# 🎯 【修復 Bug】：屬性結算完畢後，強制將當前血量補滿！
	current_hp = max_hp

func _physics_process(delta: float) -> void:
	var input_direction := Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
	if input_direction != Vector2.ZERO:
		velocity = velocity.move_toward(input_direction * max_speed, acceleration * delta)
	else:
		velocity = velocity.move_toward(Vector2.ZERO, friction * delta)
	move_and_slide()

func _process(delta: float) -> void:
	if get_tree().paused: 
		return
		
	if dialogue_cooldown > 0: dialogue_cooldown -= delta
	
	# 🎯 【大招倒數條修正】：爆發期間，能量條會絲滑地從 100% 倒數到 0%
	if is_burst_mode:
		burst_timer -= delta
		current_budget = (burst_timer / burst_duration) * max_budget
		if burst_timer <= 0:
			is_burst_mode = false
			current_budget = 10.0 # 大招結束後留下 10 點底火
			$AutoShootTimer.wait_time = 0.2 
			print("💼 Burst mode ended... Get back to work.")
		return 
		
	current_budget += budget_recovery_rate * delta
	current_budget = min(current_budget, max_budget)
	
	if current_budget <= 0:
		if not is_slacking:
			is_slacking = true
			$AutoShootTimer.wait_time = 0.5 
	elif current_budget > 20.0:
		if is_slacking:
			is_slacking = false
			$AutoShootTimer.wait_time = 0.2 
	
	if current_budget >= max_budget:
		trigger_burst_mode()

func trigger_burst_mode() -> void:
	is_burst_mode = true
	burst_timer = burst_duration
	current_budget = max_budget # 大招剛發動時保持滿格，準備倒數
	$AutoShootTimer.wait_time = 0.05 
	
	var popup = preload("res://Scene/damage_number.tscn").instantiate()
	get_tree().current_scene.add_child(popup)
	# Localized dialogue text to English
	popup.set_text_and_tween("🔥 I'M DONE! UNLEASH THE BURST!!", global_position + Vector2(0, -60))
	
	var tween = create_tween()
	tween.tween_property(player_sprite, "modulate", Color(3.0, 2.5, 0.5), 0.1)
	tween.tween_property(player_sprite, "modulate", Color(1, 1, 1), 0.2).set_delay(0.1)

func shoot() -> void:
	var enemies = get_tree().get_nodes_in_group("enemy")
	if enemies.size() == 0: return
	
	var target_pos = _find_closest_enemy_position() 
	
	if is_burst_mode:
		for angle_offset in [-0.2, 0.0, 0.2]:
			var b = bullet_scene.instantiate()
			b.global_position = global_position
			b.rotation = (target_pos - global_position).angle() + angle_offset
			get_tree().current_scene.add_child(b)
		return 

	if weapon_level == 1:
		if current_budget >= 2.0:
			current_budget -= 2.0 
			var bullet = bullet_scene.instantiate()
			bullet.global_position = global_position
			bullet.look_at(target_pos)
			get_tree().current_scene.add_child(bullet)
	elif weapon_level >= 2:
		if current_budget >= 4.0:
			current_budget -= 4.0
			var base_angle = (target_pos - global_position).angle() 
			var b1 = bullet_scene.instantiate()
			b1.global_position = global_position
			b1.rotation = base_angle - 0.15
			get_tree().current_scene.add_child(b1)
			var b2 = bullet_scene.instantiate()
			b2.global_position = global_position
			b2.rotation = base_angle + 0.15
			get_tree().current_scene.add_child(b2)

func _find_closest_enemy_position() -> Vector2:
	var enemies = get_tree().get_nodes_in_group("enemy")
	if enemies.size() == 0:
		return global_position + Vector2.RIGHT
	var closest_enemy = enemies[0]
	var min_dist = global_position.distance_to(closest_enemy.global_position)
	for enemy in enemies:
		if is_instance_valid(enemy):
			var dist = global_position.distance_to(enemy.global_position)
			if dist < min_dist:
				min_dist = dist
				closest_enemy = enemy
	return closest_enemy.global_position

func _on_hurt_box_body_entered(body: Node2D) -> void:
	if body.is_in_group("enemy"):
		if $ImmuneTimer.time_left > 0:
			return
			
		if is_slacking and randf() > 0.5:
			var popup = preload("res://Scene/damage_number.tscn").instantiate()
			get_tree().current_scene.add_child(popup)
			# Localized dodge text
			popup.set_text_and_tween("Ignored! (Dodge)", global_position + Vector2(0, -60))
			return 
			
		current_hp -= 1
		$ImmuneTimer.start()
		
		var knockback_dir = (global_position - body.global_position).normalized()
		velocity = knockback_dir * 600.0  
		
		if current_hp <= 0:
			current_hp = 0
			if get_tree().current_scene.has_method("update_ui"):
				get_tree().current_scene.update_ui()
			queue_free() 
			return       
			
		if get_tree().current_scene.has_method("update_ui"):
			get_tree().current_scene.update_ui()

func add_exp() -> void:
	current_exp += 1
	if current_exp >= max_exp:
		level_up()
	if get_tree().current_scene.has_method("update_ui"):
		get_tree().current_scene.update_ui()

# res://Script/player.gd 內部的 level_up 函式
func level_up() -> void:
	current_exp = 0
	max_exp += 2
	current_hp = max_hp
	
	player_level += 1 # 🎯 每升一級，等級實打實 +1
	
	show_level_up_text()
	recalculate_stats()

func show_level_up_text() -> void:
	var label = $LevelUpLabel
	label.text = "✨ LEVEL UP! ✨"
	label.visible = true
	label.modulate.a = 1.0 
	
	var tween = create_tween()
	var target_y = label.position.y - 40
	tween.tween_property(label, "position:y", target_y, 1.0).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	tween.parallel().tween_property(label, "modulate:a", 0.0, 1.0)
	
	tween.tween_callback(func():
		label.visible = false
		label.position.y += 40 
	)

func on_gem_collected() -> void:
	current_exp += 1
	if get_tree().current_scene.has_method("update_ui"):
		get_tree().current_scene.update_ui()
	if current_exp >= max_exp:
		level_up()
		
	var now = Time.get_ticks_msec()
	gem_timestamps.append(now)
	
	while gem_timestamps.size() > 0 and (now - gem_timestamps[0]) > 1000:
		gem_timestamps.pop_front()
		
	var combo_count = gem_timestamps.size()
	if combo_count >= 10:
		trigger_high_combo_glow()
	elif combo_count >= 3 and dialogue_cooldown <= 0:
		spawn_dialogue_text()

func trigger_high_combo_glow() -> void:
	if glow_tween and glow_tween.is_valid():
		glow_tween.kill()
	glow_tween = create_tween()
	player_sprite.modulate = Color(0.3, 3.0, 1.8)
	glow_tween.tween_property(player_sprite, "modulate", Color(1.0, 1.0, 1.0, 1.0), 0.3).set_trans(Tween.TRANS_SINE)

func spawn_dialogue_text() -> void:
	dialogue_cooldown = 2.5 
	# Localized lines to English
	var lines = ["I'm getting stronger!", "Come on baby!", "Overtime energy is surging!", "The sound of overtime pay!", "Blame shifted smoothly!"]
	var chosen_text = lines[randi() % lines.size()]
	
	var damage_number_scene = preload("res://Scene/damage_number.tscn")
	if damage_number_scene:
		var text_popup = damage_number_scene.instantiate()
		get_tree().current_scene.add_child(text_popup)
		text_popup.set_text_and_tween(chosen_text, global_position + Vector2(0, -60))

# =====================================================================
# 🧲 BACKEND DATA CORE: RECALCULATE ALL STATS FROM BACKPACK ITEMS
# =====================================================================
func recalculate_stats() -> void:
	max_hp = BASE_MAX_HP
	max_speed = BASE_MAX_SPEED
	budget_recovery_rate = BASE_BUDGET_RECOVERY_RATE
	
	discount_sword_level = 0
	greatsword_level = 0
	rumor_wand_level = 1
	
	for item in inventory_items:
		if item == null:
			continue
			
		max_hp += item.hp_modifier
		max_speed += item.speed_modifier
		budget_recovery_rate += item.budget_regen_modifier
		
		match item.weapon_type:
			1: 
				discount_sword_level += item.weapon_level_gain
			2: 
				greatsword_level += item.weapon_level_gain
			3: 
				rumor_wand_level += item.weapon_level_gain

	max_hp = max(1, max_hp)
	max_speed = max(60.0, max_speed)
	current_hp = min(current_hp, max_hp)
	weapon_level = rumor_wand_level 
	
	print("⚙️ STATS RECALCULATED | MaxHP:", max_hp, " | Speed:", max_speed, " | BudgetRegen:", budget_recovery_rate, "/s | WeaponLv:", weapon_level)
	
	if get_tree().current_scene.has_method("update_ui"):
		get_tree().current_scene.update_ui()
