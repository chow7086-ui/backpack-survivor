extends Area2D # 如果你的寶石是用 Area2D 做的

@export var magnet_range: float = 200.0  # 🔍 磁鐵吸取範圍（像素）
@export var pickup_range: float = 20.0   # 🔍 真正觸碰吃掉的距離
@export var base_speed: float = 120.0    # 初始飛向玩家的速度

var player: Node2D = null
var is_attracted: bool = false
var current_speed: float = base_speed

# 🎯 抓到寶石自己的圖片，吸取時要讓它發光
@onready var sprite: Sprite2D = $Sprite2D 

func _ready() -> void:
	player = get_tree().get_first_node_in_group("player")

func _physics_process(delta: float) -> void:
	if not player or not is_instance_valid(player):
		return
		
	# 計算與主角之間的距離
	var dist = global_position.distance_to(player.global_position)
	
	# 🧲 觸發磁鐵吸取
	if not is_attracted and dist < magnet_range:
		is_attracted = true
		
		# 🎯 【特效 1】：吸取瞬間追加發光特效（利用 Tween 一瞬間把圖片亮度拔高）
		var tween = create_tween()
		# 超過 1.0 的 Color 代表 HDR 高亮發光，這裡調成清爽的發亮藍白光
		tween.tween_property(sprite, "modulate", Color(2.0, 2.5, 4.0), 0.15)
		
	# 🚀 如果正在被吸取，就往主角飛過去
	if is_attracted:
		current_speed += 600.0 * delta # 飛行過程不斷「平滑加速」
		var dir = (player.global_position - global_position).normalized()
		global_position += dir * current_speed * delta
		
		# 🧱 抵達主角中心，正式被吃掉
		if dist < pickup_range:
			# 叫醒主角：我被你吃掉囉！
			if player.has_method("on_gem_collected"):
				player.on_gem_collected()
			queue_free() # 寶石功成身退
